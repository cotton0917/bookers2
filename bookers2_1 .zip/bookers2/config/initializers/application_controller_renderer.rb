# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '499c2b029691284201e6854305e3ecb00afca1725e68316902da7f4e4d5ab2df70ec69f35a271602cb7e2fcf7cb8730a335bed921e1740d3bbbabdd50cb93c52'